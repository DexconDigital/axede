angular.module('dexcon')
 
.constant('USER_ROLES', {
  admin: 'admin_role',
  user: 'user_role',
  consultor: 'consultor_role',
});