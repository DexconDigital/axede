angular.module('dexcon')
 
.constant('USER_ROLES', {
  admin: 'admin_role',
  user: 'rectora_role',
});